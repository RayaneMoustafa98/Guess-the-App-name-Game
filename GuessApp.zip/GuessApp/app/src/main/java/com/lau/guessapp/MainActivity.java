package com.lau.guessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.InterruptedIOException;
import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.net.ssl.HttpsURLConnection;
public class MainActivity extends AppCompatActivity implements serializable{

    ArrayList<String> AppsURLs = new ArrayList<String>();
    ArrayList<String> AppsNames = new ArrayList<String>();
    String[] splitter=new String [1000];


    public static class ImageDownloader extends AsyncTask<String, Void, Bitmap>{

        @Override
        protected Bitmap doInBackground(String... urls) {

            try {
                URL url = new URL(urls[0]);
                HttpsURLConnection connection=(HttpsURLConnection) url.openConnection();
                connection.connect();

                InputStream inputStream= connection.getInputStream();

                Bitmap myBitmap = BitmapFactory.decodeStream(inputStream);
                return myBitmap;

            }catch(Exception e){
                e.printStackTrace();
            }
            return null;
        }
    }

    public class Downloader extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String result = "";
            URL url;
            HttpsURLConnection urlConnection;
            try {
                url = new URL(strings[0]);
                urlConnection = (HttpsURLConnection) url.openConnection();
                InputStream in = urlConnection.getInputStream();

                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(in));
                StringBuilder builder = new StringBuilder();


                bufferedReader.readLine();
                splitter=result.split("<div class=\"flex flex-wrap order-3\">"); // we are splitting before this div because after it there are images that are not app icons
                while ((result = bufferedReader.readLine()) != null) {
                    builder.append(result);
                    System.out.println(result);


                    Matcher m = Pattern.compile("data-image-loader=\"(.*?)\"").matcher(result);
                    Matcher match2 = Pattern.compile("alt=\"(.*?)\"").matcher(result);



                    while(m.find()){
                        AppsURLs.add(m.group());
                        System.out.print(AppsURLs);
                    }


                    while(match2.find()){
                        AppsNames.add(m.group());
                        System.out.print(AppsNames);

                    }
                }
                for(int i=0; i<AppsURLs.size();i++){
                    System.out.println(AppsURLs.get(i)+ "TEST");
                }

                return result;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button easy = (Button) findViewById(R.id.easyLevel);
        Button medium = (Button) findViewById(R.id.mediumLevel);
        Button hard = (Button) findViewById(R.id.hardLevel);

        easy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent easyIntent = new Intent(MainActivity.this, EasyLevelActivity.class);
                easyIntent.putExtra("AppsURLs",  AppsURLs);
                easyIntent.putExtra("AppsNames", AppsNames);
                startActivity(easyIntent);
            }
        });
        medium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent mediumIntent = new Intent(MainActivity.this, MediumLevelActivity.class);
                mediumIntent.putExtra("AppsURLs",  AppsURLs);
                mediumIntent.putExtra("AppsNames",  AppsNames);
                startActivity(mediumIntent);
            }
        });
        hard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent hardIntent = new Intent(MainActivity.this, HardLevelActivity.class);
                hardIntent.putExtra("AppsURLs", AppsURLs);
                hardIntent.putExtra("AppsNames",  AppsNames);
                startActivity(hardIntent);
            }
        });




        Downloader task = new Downloader();
        String result = null;
        try {

            result = task.execute("https://www.pcmag.com/picks/best-android-apps").get();




        } catch (InterruptedException e) {

            e.printStackTrace();

        } catch (ExecutionException e) {

            e.printStackTrace();
        }


    }



}






