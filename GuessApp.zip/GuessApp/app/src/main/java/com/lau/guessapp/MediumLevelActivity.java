package com.lau.guessapp;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;


import javax.net.ssl.HttpsURLConnection;

public class MediumLevelActivity extends AppCompatActivity {

    ArrayList<String> AppsURLs = new ArrayList<String>();
    ArrayList<String> AppsNames = new ArrayList<String>();
    int chosenApp = 0;
    int score = 0;
    int locationOfCorrectAnswer = 0;
    String[] answers = new String[4];

    TextView scoreText;
    ImageView imageView;
    Button option1, option2, option3, option4;

    public void AppChosen(View view) {
        if (view.getTag().toString().equals(Integer.toString(locationOfCorrectAnswer))) {

            score+=1;

        } else {

            score-=1;
            Toast.makeText(getApplicationContext(), "Wrong Answer:( It was " + AppsNames.get(chosenApp), Toast.LENGTH_LONG).show();
        }
        scoreText.setText("Score: " +score);

        createNewQuestion();
    }


    public class ImageDownloader extends AsyncTask<String, Void, Bitmap> {

        @Override
        protected Bitmap doInBackground(String... urls) {

            try {
                Bundle bundle = getIntent().getExtras();
                AppsURLs = (ArrayList<String>) bundle.getStringArrayList("AppsURLs");
                AppsNames = (ArrayList<String>) bundle.getSerializable("AppsNames");

                URL url = new URL(urls[0]);
                HttpsURLConnection connection = (HttpsURLConnection) url.openConnection();
                connection.connect();

                InputStream inputStream = connection.getInputStream();

                Bitmap myBitmap = BitmapFactory.decodeStream(inputStream);
                return myBitmap;

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easylevel);

        scoreText = (TextView) findViewById(R.id.score);
        imageView = (ImageView) findViewById(R.id.imageView);
        option1 = (Button) findViewById(R.id.button1);
        option2 = (Button) findViewById(R.id.button2);
        option3 = (Button) findViewById(R.id.button3);
        option4 = (Button) findViewById(R.id.button4);

        Bundle bundle = getIntent().getExtras();
        AppsURLs = (ArrayList<String>) bundle.getStringArrayList("AppsURLs");
        AppsNames = (ArrayList<String>) bundle.getSerializable("AppsNames");



        createNewQuestion ();


    }
    public void createNewQuestion (){


        Random random = new Random();
        chosenApp = random.nextInt(AppsURLs.size());

        ImageDownloader imageTask = new ImageDownloader();
        Bitmap AppImage;
        try {
            AppImage = imageTask.execute(AppsURLs.get(chosenApp)).get();

            imageView.setImageBitmap(AppImage);

            locationOfCorrectAnswer = random.nextInt(4);

            int incorrectAnswerLocation;

            for (int i = 0; i < 4; i++) {

                if (i == locationOfCorrectAnswer) {

                    answers[i] = AppsNames.get(chosenApp);

                } else {

                    incorrectAnswerLocation = random.nextInt(AppsURLs.size());

                    while (incorrectAnswerLocation == chosenApp) {
                        incorrectAnswerLocation = random.nextInt(AppsURLs.size());

                    }
                    answers[i] = AppsNames.get(incorrectAnswerLocation);


                }
            }

            option1.setText(answers[0]);
            option2.setText(answers[1]);
            option3.setText(answers[2]);
            option4.setText(answers[3]);


        }catch (Exception e) {

            e.printStackTrace();
        }


    }
}











