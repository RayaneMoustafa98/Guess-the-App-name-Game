package com.lau.guessapp;

public interface serializable {
}
